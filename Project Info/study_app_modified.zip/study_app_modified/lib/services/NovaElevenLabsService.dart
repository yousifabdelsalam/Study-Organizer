// nova_elevenlabs_service.dart — ElevenLabs AI Voice for NOVA
//
// Replaces Flutter TTS with ElevenLabs API for high-quality AI voice.
// Falls back to Flutter TTS if ElevenLabs key is missing or call fails.
//
// HOW IT WORKS:
// 1. User sets their ElevenLabs API key + Voice ID in NOVA Settings.
// 2. When NOVA speaks, this service calls /v1/text-to-speech/{voice_id}
//    with the streaming endpoint and plays back via audioplayers.
// 3. Uses "eleven_turbo_v2_5" model — lowest latency, best for chat (~400ms).
// 4. Caches audio bytes in memory (last 5 phrases) to avoid re-fetching.
//
// SETUP FOR USER:
// 1. Go to elevenlabs.io → sign in → My Voices → your Jarvis voice
// 2. Copy Voice ID (looks like: "AbCdEfGhIjKlMnOp1234")
// 3. Go to Profile → API Key → copy key (starts with "sk_")
// 4. Paste both in NOVA Settings → Voice section
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_tts/flutter_tts.dart';

const _prefElevenLabsKey = 'elevenlabs_api_key';
const _prefElevenVoiceId = 'elevenlabs_voice_id';
const _prefUseElevenLabs = 'use_elevenlabs_tts';

// ElevenLabs model — turbo_v2_5 has lowest latency (~300-500ms) for chat
const _kModel = 'eleven_turbo_v2_5';

class NovaElevenLabsService {
  // ── Settings ───────────────────────────────────────────────────────────────
  static Future<String?> getApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    final k = prefs.getString(_prefElevenLabsKey)?.trim() ?? '';
    return k.isEmpty ? null : k;
  }

  static Future<String?> getVoiceId() async {
    final prefs = await SharedPreferences.getInstance();
    final v = prefs.getString(_prefElevenVoiceId)?.trim() ?? '';
    return v.isEmpty ? null : v;
  }

  static Future<bool> isEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    final enabled = prefs.getBool(_prefUseElevenLabs) ?? false;
    if (!enabled) return false;
    final key = await getApiKey();
    final vid = await getVoiceId();
    return key != null && vid != null;
  }

  static Future<void> setApiKey(String key) async =>
      (await SharedPreferences.getInstance()).setString(
        _prefElevenLabsKey,
        key.trim(),
      );

  static Future<void> setVoiceId(String id) async =>
      (await SharedPreferences.getInstance()).setString(
        _prefElevenVoiceId,
        id.trim(),
      );

  static Future<void> setEnabled(bool value) async =>
      (await SharedPreferences.getInstance()).setBool(
        _prefUseElevenLabs,
        value,
      );

  // ── Audio player ──────────────────────────────────────────────────────────
  static final AudioPlayer _player = AudioPlayer();
  static bool _playing = false;

  // Simple in-memory cache: text hash → temp file path
  static final Map<int, String> _cache = {};

  // ── Fallback Flutter TTS ──────────────────────────────────────────────────
  static final FlutterTts _fallbackTts = FlutterTts();
  static bool _fallbackSetup = false;

  static Future<void> _setupFallback() async {
    if (_fallbackSetup) return;
    await _fallbackTts.setLanguage('en-US');
    await _fallbackTts.setSpeechRate(0.52);
    await _fallbackTts.setPitch(0.65);
    await _fallbackTts.awaitSpeakCompletion(false);
    _fallbackSetup = true;
  }

  // ── Main speak method ─────────────────────────────────────────────────────
  /// Speak text using ElevenLabs if enabled, else Flutter TTS.
  /// Non-blocking — returns immediately, audio plays in background.
  static Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;

    // Truncate very long texts (ElevenLabs charges per character)
    final truncated = text.length > 500 ? '${text.substring(0, 500)}...' : text;

    if (await isEnabled()) {
      _speakElevenLabs(truncated);
    } else {
      await _setupFallback();
      _fallbackTts.speak(truncated);
    }
  }

  /// Stop any ongoing speech.
  static Future<void> stop() async {
    _playing = false;
    try {
      await _player.stop();
    } catch (_) {}
    try {
      await _fallbackTts.stop();
    } catch (_) {}
  }

  // ── ElevenLabs API call ───────────────────────────────────────────────────
  static Future<void> _speakElevenLabs(String text) async {
    try {
      // Check cache first
      final cacheKey = text.hashCode;
      if (_cache.containsKey(cacheKey)) {
        final cachedPath = _cache[cacheKey]!;
        if (File(cachedPath).existsSync()) {
          await _playFile(cachedPath);
          return;
        }
      }

      final key = await getApiKey();
      final voiceId = await getVoiceId();
      if (key == null || voiceId == null) {
        await _setupFallback();
        _fallbackTts.speak(text);
        return;
      }

      final uri = Uri.parse(
        'https://api.elevenlabs.io/v1/text-to-speech/$voiceId?optimize_streaming_latency=2',
      );

      final response = await http
          .post(
            uri,
            headers: {
              'xi-api-key': key,
              'Content-Type': 'application/json',
              'Accept': 'audio/mpeg',
            },
            body:
                '''{
  "text": ${_jsonString(text)},
  "model_id": "$_kModel",
  "voice_settings": {
    "stability": 0.4,
    "similarity_boost": 0.9,
    "style": 0.1,
    "use_speaker_boost": true
  }
}''',
          )
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final audioBytes = response.bodyBytes;
        final path = await _saveToTemp(audioBytes, cacheKey);
        _cache[cacheKey] = path;
        // Keep cache small
        if (_cache.length > 5) {
          final oldest = _cache.keys.first;
          try {
            File(_cache[oldest]!).deleteSync();
          } catch (_) {}
          _cache.remove(oldest);
        }
        await _playFile(path);
      } else {
        debugPrint(
          '[ElevenLabs] Error ${response.statusCode}: ${response.body.substring(0, 200.clamp(0, response.body.length))}',
        );
        // Fallback to Flutter TTS on any error
        await _setupFallback();
        _fallbackTts.speak(text);
      }
    } catch (e) {
      debugPrint('[ElevenLabs] speak error: $e');
      await _setupFallback();
      _fallbackTts.speak(text);
    }
  }

  static Future<String> _saveToTemp(Uint8List bytes, int key) async {
    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/nova_voice_$key.mp3';
    await File(path).writeAsBytes(bytes);
    return path;
  }

  static Future<void> _playFile(String path) async {
    try {
      await _player.stop();
      _playing = true;
      await _player.play(DeviceFileSource(path));
      _player.onPlayerComplete.first.then((_) => _playing = false);
    } catch (e) {
      debugPrint('[ElevenLabs] playFile error: $e');
      _playing = false;
    }
  }

  /// Encode text as a JSON string (handles quotes, backslashes, newlines).
  static String _jsonString(String text) {
    final escaped = text
        .replaceAll('\\', '\\\\')
        .replaceAll('"', '\\"')
        .replaceAll('\n', ' ')
        .replaceAll('\r', '');
    return '"$escaped"';
  }

  /// Test the ElevenLabs connection — returns error message or null on success.
  static Future<String?> testConnection() async {
    final key = await getApiKey();
    final voiceId = await getVoiceId();
    if (key == null) return 'No API key set.';
    if (voiceId == null) return 'No Voice ID set.';

    try {
      final response = await http
          .get(
            Uri.parse('https://api.elevenlabs.io/v1/voices/$voiceId'),
            headers: {'xi-api-key': key},
          )
          .timeout(const Duration(seconds: 8));

      if (response.statusCode == 200) {
        await speak('Online and ready, sir.');
        return null; // success
      }
      if (response.statusCode == 401) return 'Invalid API key.';
      if (response.statusCode == 404)
        return 'Voice ID not found. Double-check your Voice ID.';
      return 'Error ${response.statusCode}. Check your key and voice ID.';
    } catch (e) {
      return 'Connection failed: ${e.toString().split('\n').first}';
    }
  }

  static bool get isPlaying => _playing;
}
