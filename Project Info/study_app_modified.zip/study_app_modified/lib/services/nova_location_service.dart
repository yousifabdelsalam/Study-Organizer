// nova_location_service.dart
// Detects whether the user is currently at their saved home location.
// Uses geolocator package. Requires ACCESS_FINE_LOCATION permission.

import 'package:geolocator/geolocator.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NovaLocationService {
  static const _prefHomeLat  = 'nova_home_lat';
  static const _prefHomeLng  = 'nova_home_lng';
  static const _homeRadius   = 150.0; // metres

  // ── Save current position as home ────────────────────────────────────────
  static Future<bool> saveHomeLocation() async {
    try {
      final pos = await _currentPosition();
      if (pos == null) return false;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble(_prefHomeLat, pos.latitude);
      await prefs.setDouble(_prefHomeLng, pos.longitude);
      return true;
    } catch (_) { return false; }
  }

  // ── Check if user is at home ──────────────────────────────────────────────
  /// Returns true when at home.
  /// Returns false when away, location unavailable, or no home saved.
  static Future<bool> isAtHome() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final homeLat = prefs.getDouble(_prefHomeLat);
      final homeLng = prefs.getDouble(_prefHomeLng);
      if (homeLat == null || homeLng == null) return false; // no home set

      final pos = await _currentPosition(timeout: const Duration(seconds: 5));
      if (pos == null) return false;

      final dist = Geolocator.distanceBetween(
        homeLat, homeLng, pos.latitude, pos.longitude,
      );
      return dist <= _homeRadius;
    } catch (_) { return false; }
  }

  static bool hasHomeSet = false;
  static Future<void> checkHomeSet() async {
    final prefs = await SharedPreferences.getInstance();
    hasHomeSet = prefs.getDouble(_prefHomeLat) != null;
  }

  static Future<void> clearHome() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_prefHomeLat);
    await prefs.remove(_prefHomeLng);
    hasHomeSet = false;
  }

  // ── Internal: get current position with permission handling ──────────────
  static Future<Position?> _currentPosition({
    Duration timeout = const Duration(seconds: 8),
  }) async {
    try {
      LocationPermission perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) return null;

      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
        timeLimit: timeout,
      );
    } catch (_) { return null; }
  }
}
