import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../models/task.dart';
import '../models/topic.dart';
import '../models/mark.dart';
import '../bloc/app_bloc.dart';
import '../services/jarvis_brain_service.dart';
import '../services/nova_audio_service.dart';
import '../widgets/glass.dart';

class NightBeforeOverlay extends StatefulWidget {
  final List<TaskModel> exams;

  const NightBeforeOverlay({super.key, required this.exams});

  @override
  State<NightBeforeOverlay> createState() => _NightBeforeOverlayState();
}

class _NightBeforeOverlayState extends State<NightBeforeOverlay> {
  bool _loading = true;
  String _studyPlan = '';
  List<StudyTopic> _weakTopics = [];
  List<MarkModel> _warnings = [];

  @override
  void initState() {
    super.initState();
    NovaAudioService.playAsset(
      'sounds/attention_critical_exam_detected_for_tomorrow.mp3',
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initializeBriefing();
    });
  }

  Future<void> _initializeBriefing() async {
    final state = context.read<AppBloc>().state;

    // Top 5 weakest topics
    var eligibleTopics = state.topics
        .where((t) => !t.isMastered && t.stage < 4)
        .toList();
    eligibleTopics.sort((a, b) => a.stage.compareTo(b.stage));
    _weakTopics = eligibleTopics.take(5).toList();

    // Mark Surgeon Warnings
    _warnings = state.marks
        .where((m) => m.lossReason != null && m.lossReason!.isNotEmpty)
        .toList();
    _warnings.sort(
      (a, b) => b.createdAt?.compareTo(a.createdAt ?? DateTime(0)) ?? 0,
    );
    _warnings = _warnings.take(3).toList();

    final examTitles = widget.exams.map((e) => e.title).toList();
    final topicsStrs = _weakTopics.map((t) => t.title).toList();
    final warningStrs = _warnings.map((m) => m.lossReason!).toList();

    final plan = await JarvisBrainService.generateNightBeforePlan(
      examTitles,
      topicsStrs,
      warningStrs,
    );

    if (!mounted) return;
    setState(() {
      _studyPlan = plan;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black87,
      child: SafeArea(
        child: _loading
            ? const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.shield_moon_rounded,
                      color: Colors.redAccent,
                      size: 64,
                    ),
                    SizedBox(height: 24),
                    CircularProgressIndicator(color: Colors.redAccent),
                    SizedBox(height: 16),
                    Text(
                      'COMPILING NIGHT BEFORE PROTOCOL...',
                      style: TextStyle(
                        color: Colors.redAccent,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
              )
            : CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.all(24.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.shield_moon_rounded,
                                color: Colors.redAccent,
                                size: 36,
                              ),
                              SizedBox(width: 12),
                              Text(
                                'NIGHT BEFORE PROTOCOL',
                                style: TextStyle(
                                  color: Colors.redAccent,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 2,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'WARNING: CRITICAL EVENTS TOMORROW',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1,
                            ),
                          ),
                          const SizedBox(height: 32),

                          // Target Events
                          const Text(
                            'TARGETS',
                            style: TextStyle(
                              color: Colors.white54,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                            ),
                          ),
                          const SizedBox(height: 8),
                          ...widget.exams.map(
                            (e) => Container(
                              margin: const EdgeInsets.only(bottom: 8),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 12,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.redAccent.withOpacity(0.1),
                                border: Border.all(
                                  color: Colors.redAccent.withOpacity(0.3),
                                ),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Row(
                                children: [
                                  const Icon(
                                    Icons.warning_amber_rounded,
                                    color: Colors.redAccent,
                                    size: 20,
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      e.title,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),

                          // Weak Points
                          if (_weakTopics.isNotEmpty) ...[
                            const Text(
                              'IDENTIFIED VULNERABILITIES',
                              style: TextStyle(
                                color: Colors.white54,
                                fontSize: 12,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.5,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: _weakTopics
                                  .map(
                                    (t) => Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 12,
                                        vertical: 6,
                                      ),
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.05),
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(
                                          color: Colors.redAccent.withOpacity(
                                            0.5,
                                          ),
                                        ),
                                      ),
                                      child: Text(
                                        t.title,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  )
                                  .toList(),
                            ),
                            const SizedBox(height: 24),
                          ],

                          // Mark Surgeon Warnings
                          if (_warnings.isNotEmpty) ...[
                            const Text(
                              'HISTORIC MARK SURGEON WARNINGS',
                              style: TextStyle(
                                color: Colors.white54,
                                fontSize: 12,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.5,
                              ),
                            ),
                            const SizedBox(height: 8),
                            ..._warnings.map(
                              (w) => Padding(
                                padding: const EdgeInsets.only(bottom: 6),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text(
                                      '• ',
                                      style: TextStyle(
                                        color: Colors.redAccent,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Expanded(
                                      child: Text(
                                        w.lossReason!,
                                        style: const TextStyle(
                                          color: Colors.white70,
                                          fontSize: 13,
                                          height: 1.3,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(height: 24),
                          ],

                          // AI Plan
                          const Text(
                            'JARVIS 90-MINUTE ATTACK PLAN',
                            style: TextStyle(
                              color: Colors.white54,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1.5,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Glass(
                            padding: const EdgeInsets.all(20),
                            child: Text(
                              _studyPlan,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                height: 1.5,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          const SizedBox(height: 32),

                          ElevatedButton(
                            onPressed: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                    'Good luck sir. I\'ll leave you to it.',
                                  ),
                                  backgroundColor: Color(0xFF2ED573),
                                ),
                              );
                              Navigator.pop(context);
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.redAccent,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 18),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: const Text(
                              'I\'m Ready.',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
