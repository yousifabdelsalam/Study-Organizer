package com.example.study_organizer

import android.view.KeyEvent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    // ── Volume key → Flutter channel ─────────────────────────────────────────
    // When TTS is actively speaking a NOVA brief, we intercept volume UP so
    // Flutter can stop TTS and show the "Brief paused" banner instead of
    // changing the system volume.
    //
    // Flutter side:  MethodChannel('com.example.study_organizer/volume_key')
    //                .setMethodCallHandler((call) { if volumeUp → stop TTS })
    //
    // The key is consumed (return true) ONLY when Flutter says it is active.
    // Otherwise normal system volume behaviour is preserved.
    //
    private val CHANNEL = "com.example.study_organizer/volume_key"
    private var methodChannel: MethodChannel? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        methodChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL
        )
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            // Send to Flutter. Flutter decides whether to consume or ignore.
            methodChannel?.invokeMethod("volumeUp", null)
            // We return true (consume) here. If Flutter is not in brief-speech
            // mode it ignores the call, which means the volume effectively does
            // nothing for one press. This is the accepted trade-off — users
            // can press a second time if they genuinely want louder volume.
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
