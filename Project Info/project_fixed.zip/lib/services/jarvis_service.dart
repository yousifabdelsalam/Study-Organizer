import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:record/record.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:intl/intl.dart' as intl;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/subject.dart';
import '../models/task.dart';
import '../models/timetable.dart';
import '../models/mark.dart';
import '../models/topic.dart';
import '../models/subject_note.dart';
import '../models/jarvis_document.dart';
import 'jarvis_brain_service.dart';

// ─────────────────────────────────────────────────────────────────────────────
// ACTION TYPES
// ─────────────────────────────────────────────────────────────────────────────
enum JarvisActionType {
  navigatePage,
  navigateTab,
  addTask,
  updateTask,
  deleteTask,
  completeTask,
  addAbsence,
  deleteAbsence,
  queryAbsences,
  addNote,
  deleteNote,
  queryNotes,
  addSubject,
  deleteSubject,
  addTimetable,
  deleteTimetable,
  addMark,
  addReminder,
  pomodoroStart,
  pomodoroStop,
  pomodoroReset,
  pomodoroMode,
  querySchedule,
  needsMoreInfo,
  multipleActions,
  brainChat,
  unknown,
}

class JarvisAction {
  final JarvisActionType type;
  final String spokenResponse;
  final dynamic payload;
  final String transcription;
  final String? followUpQuestion;

  const JarvisAction({
    required this.type,
    required this.spokenResponse,
    required this.payload,
    required this.transcription,
    this.followUpQuestion,
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// LIVE VOICE STREAMING: tap-to-start, auto-submit on silence
// Uses the already-working `record` package → Groq Whisper API.
// No on-device STT plugin needed.
// ─────────────────────────────────────────────────────────────────────────────
const String _prefGroqKey = 'groq_api_key';
const String _kGroqKeyFallback =
    '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';

class JarvisService {
  // ── API key ───────────────────────────────────────────────────────────────
  static Future<String?> _getGroqKey() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString(_prefGroqKey);
    return (saved != null && saved.isNotEmpty) ? saved : _kGroqKeyFallback;
  }

  static Future<void> setGroqKey(String key) async =>
      (await SharedPreferences.getInstance()).setString(
        _prefGroqKey,
        key.trim(),
      );

  // ── Live stream state (record → silence → Whisper) ────────────────────────
  static AudioRecorder? _recorder;
  static String? _recPath;
  static bool _isStreaming = false; // live tap-to-talk active
  static bool _isRecording = false; // whisper-mode active
  static bool useEnglish = true;

  // Silence detection: amplitude is polled every [_pollMs] ms;
  // if below threshold for [_silenceThresholdMs] ms → auto-submit.
  static const int _pollMs = 200;
  static const double _silenceDbLevel =
      -35.0; // raised from -40 (less hair-trigger)
  static Timer? _pollTimer;
  static int _silenceMs = 0;
  static DateTime? _streamStart;

  // Partial transcript feedback (text shows as "🎤 Recording…" while live)
  static final StreamController<String> _transcriptStreamCtrl =
      StreamController<String>.broadcast();
  static Stream<String> get transcriptStream => _transcriptStreamCtrl.stream;
  static String get liveTranscript => _isStreaming ? '🎤 Listening…' : '';
  static bool get isListeningLive => _isStreaming;
  static bool get isRecording => _isRecording;

  // ── Multi-turn state ──────────────────────────────────────────────────────
  static String? _pendingAction;
  static Map<String, dynamic> _pendingPayload = {};
  static bool get hasPendingAction => _pendingAction != null;
  static void clearPending() {
    _pendingAction = null;
    _pendingPayload = {};
  }

  // ── JARVIS name ───────────────────────────────────────────────────────────
  static String _jarvisName = 'NOVA';
  static void setJarvisName(String name) =>
      _jarvisName = name.trim().isEmpty ? 'NOVA' : name.trim();

  // ── Permission helper ─────────────────────────────────────────────────────
  static Future<bool> _hasPermission() async {
    final status = await Permission.microphone.request();
    return status.isGranted;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // LIVE TAP-TO-TALK (streaming: tap = start, silence = auto-submit, tap = stop)
  // Uses record package + Groq Whisper for transcription.
  // ─────────────────────────────────────────────────────────────────────────

  /// Start live recording. [onStatusUpdate] fires periodically with status text.
  /// [onDone] fires when audio is submitted and transcription is ready.
  static Future<bool> startListeningStream({
    required void Function(String text, bool isFinal) onResult,
    required void Function(String finalText) onDone,
    int silenceSeconds = 1, // reduced from 2 for faster response
  }) async {
    if (_isStreaming || _isRecording) return false;
    if (!await _hasPermission()) return false;

    _recorder?.dispose();
    _recorder = AudioRecorder();

    final dir = await getTemporaryDirectory();
    _recPath =
        '${dir.path}/jarvis_live_${DateTime.now().millisecondsSinceEpoch}.m4a';
    _silenceMs = 0;
    _streamStart = DateTime.now();

    try {
      await _recorder!.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          sampleRate: 16000,
          numChannels:
              1, // MONO — fixes stereo channel warning, better for Whisper
        ),
        path: _recPath!,
      );
    } catch (e) {
      debugPrint('record start error: $e');
      return false;
    }

    _isStreaming = true;
    onResult('🎤 Listening…', false);
    _transcriptStreamCtrl.add('🎤 Listening…');

    // Poll amplitude for silence detection
    _pollTimer = Timer.periodic(const Duration(milliseconds: _pollMs), (
      t,
    ) async {
      if (!_isStreaming) {
        t.cancel();
        return;
      }

      // Show elapsed time as feedback
      final elapsed = DateTime.now().difference(_streamStart!).inSeconds;
      onResult('🎤 Recording… ${elapsed}s', false);

      try {
        final amp = await _recorder?.getAmplitude();
        final db = amp?.current ?? _silenceDbLevel;
        if (db < _silenceDbLevel) {
          _silenceMs += _pollMs;
          if (_silenceMs >= silenceSeconds * 1000) {
            // Silence threshold hit → auto-submit
            t.cancel();
            await stopListeningStream(onDone: onDone);
          }
        } else {
          _silenceMs = 0; // reset on any sound
        }
      } catch (_) {}
    });

    return true;
  }

  /// Stop live recording and transcribe via Whisper.
  static Future<void> stopListeningStream({
    void Function(String)? onDone,
  }) async {
    if (!_isStreaming) return;
    _pollTimer?.cancel();
    _isStreaming = false;

    try {
      await _recorder?.stop();
      await Future.delayed(const Duration(milliseconds: 200));
    } catch (e) {
      debugPrint('stop error: $e');
    }

    if (_recPath == null) {
      onDone?.call('');
      return;
    }

    final file = File(_recPath!);
    final len = await file.length().catchError((_) => 0);
    if (len < 1500) {
      onDone?.call('');
      return;
    }

    final text = await _transcribe(file);
    _transcriptStreamCtrl.add(text);
    onDone?.call(text);
  }

  /// Stop immediately (called on second tap) and transcribe.
  static Future<String> stopListeningStreamImmediate() async {
    _pollTimer?.cancel();
    _isStreaming = false;
    try {
      await _recorder?.stop();
      await Future.delayed(const Duration(milliseconds: 200));
    } catch (_) {}
    if (_recPath == null) return '';
    final file = File(_recPath!);
    final len = await file.length().catchError((_) => 0);
    if (len < 1500) return '';
    return _transcribe(file);
  }

  // ── Legacy Whisper hold-to-talk ───────────────────────────────────────────
  static Future<bool> startRecording() async {
    if (!await _hasPermission()) return false;
    _recorder?.dispose();
    _recorder = AudioRecorder();
    final dir = await getTemporaryDirectory();
    _recPath =
        '${dir.path}/jarvis_${DateTime.now().millisecondsSinceEpoch}.m4a';
    await _recorder!.start(
      const RecordConfig(
        encoder: AudioEncoder.aacLc,
        sampleRate: 16000,
        numChannels: 1,
      ),
      path: _recPath!,
    );
    await Future.delayed(const Duration(milliseconds: 600));
    return _isRecording = true;
  }

  static Future<JarvisAction?> stopAndProcess({
    required List<Subject> subjects,
    required List<TaskModel> tasks,
    required List<Map<String, dynamic>> absences,
    required List<MarkModel> marks,
    required List<TimetableEntry> timetable,
    required List<StudyTopic> topics,
    required List<SubjectNote> notes,
    required List<JarvisDocument> documents,
    String? brainContext,
    List<Map<String, String>>? brainHistory,
    String personalityMode = 'normal',
  }) async {
    if (!_isRecording) return null;
    _isRecording = false;
    await _recorder?.stop();
    await Future.delayed(const Duration(milliseconds: 300));
    final file = File(_recPath ?? '');
    if (!await file.exists() || await file.length() < 1500) {
      return _fallback(
        useEnglish ? 'Speak louder — audio was too short.' : 'تكلم بصوت أعلى.',
      );
    }
    final text = await _transcribe(file);
    if (text.isEmpty) {
      return _fallback(
        useEnglish
            ? 'Could not understand. Try again.'
            : 'لم أفهم. حاول مرة أخرى.',
      );
    }
    return processText(
      text,
      subjects: subjects,
      tasks: tasks,
      absences: absences,
      marks: marks,
      timetable: timetable,
      topics: topics,
      notes: notes,
      documents: documents,
      brainContext: brainContext,
      brainHistory: brainHistory,
      personalityMode: personalityMode,
    );
  }

  // ── Process transcribed text ──────────────────────────────────────────────
  // ── Activation keyword check ─────────────────────────────────────────────
  // Runs BEFORE any AI call. Pure local match — instant, zero latency.
  // Returns a JarvisAction if text matches a known activation phrase,
  // null otherwise (falls through to normal AI processing).
  static JarvisAction? _checkActivationKeyword(
    String text,
    List<TimetableEntry> timetable,
    List<Subject> subjects,
    List<TaskModel> tasks,
  ) {
    final t = text
        .toLowerCase()
        .replaceAll(RegExp(r"[^\w\s']"), '')
        .trim();

    String? reply;

    // ── Identity / wake phrases ──
    if (_kw(t, ['are you up', 'up for me', 'you up for'])) {
      reply = "I'm always up for you, sir.";
    } else if (_kw(t, ['are you there', 'you there'])) {
      reply = "Always here, sir.";
    } else if (_kw(t, ['wake up', 'wake up nova', 'nova wake'])) {
      reply = "I never sleep, sir.";
    } else if (_kw(t, ['you online', 'are you online', 'you active'])) {
      reply = "Online and fully operational, sir.";
    } else if (_kw(t, ['hello nova', 'hey nova', 'hi nova'])) {
      reply = "Hello, sir. What do you need?";
    }

    // ── Status / quick summary ──
    else if (_kw(t, ['nova status', 'status report', 'give me a status'])) {
      final now = DateTime.now();
      final pending = tasks.where((t) => !t.isCompleted).length;
      final today = timetable
          .where((e) => e.dayOfWeek == now.weekday)
          .length;
      reply = "Status: $today classes today, $pending pending tasks. "
          "All systems nominal, sir.";
    }

    // ── Plan / schedule quick phrases ──
    else if (_kw(t, ["whats my plan", "what's my plan", "my plan today",
                      "plan for today", "today plan"])) {
      reply = "Opening your study plan now, sir.";
      // This one also fires navigation — handled by caller via payload
    } else if (_kw(t, ["what do i have next", "whats next", "what's next",
                       "next class", "next up"])) {
      final now = DateTime.now();
      final nowMin = now.hour * 60 + now.minute;
      final todayEntries = timetable
          .where((e) => e.dayOfWeek == now.weekday)
          .toList()
        ..sort((a, b) => a.startTime.compareTo(b.startTime));

      TimetableEntry? next;
      for (final e in todayEntries) {
        final parts = e.startTime.split(':');
        if (parts.length < 2) continue;
        final eMin = int.parse(parts[0]) * 60 + int.parse(parts[1]);
        if (eMin > nowMin) { next = e; break; }
      }

      if (next == null) {
        reply = "No more classes today, sir. The day is yours.";
      } else {
        final sub = subjects
            .where((s) => s.id == next!.subjectId)
            .map((s) => s.name)
            .firstOrNull ?? 'class';
        reply = "Next up: $sub at ${next.startTime}, "
                "${next.type} in ${next.room}.";
      }
    }

    if (reply == null) return null;

    return JarvisAction(
      type: JarvisActionType.brainChat,
      spokenResponse: reply,
      payload: const {},
      transcription: text,
    );
  }

  /// Helper — true if any phrase in [keywords] appears anywhere in [text].
  static bool _kw(String text, List<String> keywords) =>
      keywords.any((k) => text.contains(k));

  static Future<JarvisAction> processText(
    String text, {
    required List<Subject> subjects,
    required List<TaskModel> tasks,
    required List<Map<String, dynamic>> absences,
    required List<MarkModel> marks,
    required List<TimetableEntry> timetable,
    required List<StudyTopic> topics,
    required List<SubjectNote> notes,
    required List<JarvisDocument> documents,
    String? brainContext,
    List<Map<String, String>>? brainHistory,
    String personalityMode = 'normal',
  }) async {
    // ── 1. Pending multi-turn conversation takes priority ──
    if (_pendingAction != null) {
      return _resolvePending(text, subjects, brainContext, brainHistory);
    }

    // ── 2. Activation keyword check — instant, zero API cost ──
    final activation = _checkActivationKeyword(text, timetable, subjects, tasks);
    if (activation != null) return activation;

    // ── 3. Normal AI processing ──
    return _processWithAI(
      text,
      subjects,
      tasks,
      absences,
      marks,
      timetable,
      topics,
      notes,
      documents,
      brainContext: brainContext,
      brainHistory: brainHistory,
      personalityMode: personalityMode,
    );
  }

  // ── Whisper STT ───────────────────────────────────────────────────────────
  static Future<String> _transcribe(File file) async {
    try {
      final key = await _getGroqKey();
      if (key == null || key.isEmpty) return '';
      final req = http.MultipartRequest(
        'POST',
        Uri.parse('https://api.groq.com/openai/v1/audio/transcriptions'),
      );
      req.headers['Authorization'] = 'Bearer $key';
      req.files.add(
        await http.MultipartFile.fromPath(
          'file',
          file.path,
          filename: 'audio.m4a',
        ),
      );
      req.fields['model'] = 'whisper-large-v3-turbo';
      req.fields['language'] = useEnglish ? 'en' : 'ar';
      final res = await http.Response.fromStream(await req.send());
      if (res.statusCode == 200) {
        final text = jsonDecode(res.body)['text']?.toString().trim() ?? '';
        final lower = text
            .toLowerCase()
            .replaceAll(RegExp(r'[^\w\s]'), '')
            .trim();
        // Filter common Whisper-large-v3 hallucinations on pure silence/noise
        if (lower == 'thank you' ||
            lower == 'thanks' ||
            lower == 'thank you so much' ||
            lower == 'thank you for watching' ||
            lower == 'thanks for watching' ||
            lower == 'bye' ||
            lower == 'you' ||
            lower == 'amen' ||
            lower == 'amine' ||
            lower == 'subscribe' ||
            lower.isEmpty) {
          debugPrint('Filtered Whisper hallucination: "$text"');
          return '';
        }
        return text;
      }
      debugPrint('Whisper error: ${res.statusCode}');
    } catch (e) {
      debugPrint('Transcription error: $e');
    }
    return '';
  }

  // ── AI processing ─────────────────────────────────────────────────────────
  static Future<JarvisAction> _processWithAI(
    String text,
    List<Subject> subjects,
    List<TaskModel> tasks,
    List<Map<String, dynamic>> absences,
    List<MarkModel> marks,
    List<TimetableEntry> timetable,
    List<StudyTopic> topics,
    List<SubjectNote> notes,
    List<JarvisDocument> documents, {
    String? brainContext,
    List<Map<String, String>>? brainHistory,
    String personalityMode = 'normal',
  }) async {
    try {
      final prompt = _buildPrompt(
        DateTime.now(),
        subjects,
        tasks,
        absences,
        marks,
        timetable,
        topics,
        notes,
        documents,
        text,
      );
      final result = await JarvisBrainService.generateRaw(
        prompt: prompt,
        maxTokens: 2048,
        temperature: 0.1,
        isJson: true,
      );
      if (result != null && result.isNotEmpty) {
        return _parseResponse(
          result,
          text,
          subjects,
          brainContext,
          brainHistory,
        );
      }
    } catch (e) {
      debugPrint('AI error: $e');
    }
    if (brainContext != null) {
      final reply = await JarvisBrainService.chat(
        context: brainContext,
        history: brainHistory ?? [],
        userMessage: text,
        personalityMode: personalityMode,
      );
      return JarvisAction(
        type: JarvisActionType.brainChat,
        spokenResponse: reply,
        payload: {},
        transcription: text,
      );
    }
    return _fallback(useEnglish ? 'Something went wrong.' : 'حدث خطأ.');
  }

  // ── Multi-turn resolver ───────────────────────────────────────────────────
  static Future<JarvisAction> _resolvePending(
    String userReply,
    List<Subject> subjects,
    String? brainContext,
    List<Map<String, String>>? brainHistory,
  ) async {
    final action = _pendingAction!;
    if (action == 'add_note_subject') {
      _pendingPayload['subject'] = userReply;
      _pendingAction = 'add_note_content';
      const q = 'What should the note say, sir?';
      return JarvisAction(
        type: JarvisActionType.needsMoreInfo,
        spokenResponse: q,
        followUpQuestion: q,
        payload: Map.from(_pendingPayload),
        transcription: userReply,
      );
    }
    if (action == 'add_note_content') {
      _pendingPayload['content'] = userReply;
      final p = Map<String, dynamic>.from(_pendingPayload);
      clearPending();
      final subName = p['subject']?.toString() ?? '';
      final sub = subjects.firstWhere(
        (s) => s.name.toLowerCase().contains(subName.toLowerCase()),
        orElse: () =>
            subjects.isNotEmpty ? subjects.first : Subject(name: subName),
      );
      return JarvisAction(
        type: JarvisActionType.addNote,
        spokenResponse: useEnglish
            ? 'Note added to ${sub.name}, sir.'
            : 'تمت الإضافة.',
        payload: {
          'subject': sub.name,
          'title': p['title'] ?? 'Voice Note',
          'content': p['content'],
        },
        transcription: userReply,
      );
    }
    if (action == 'add_absence_subject') {
      _pendingPayload['subject'] = userReply;
      _pendingAction = 'add_absence_type';
      const q = 'What type, sir? Lecture, section, or lab?';
      return JarvisAction(
        type: JarvisActionType.needsMoreInfo,
        spokenResponse: q,
        followUpQuestion: q,
        payload: Map.from(_pendingPayload),
        transcription: userReply,
      );
    }
    if (action == 'add_absence_type') {
      final type = _mapAbsenceType(userReply);
      _pendingPayload['type'] = type;
      final p = Map<String, dynamic>.from(_pendingPayload);
      clearPending();
      return JarvisAction(
        type: JarvisActionType.addAbsence,
        spokenResponse: useEnglish
            ? 'Absence recorded for ${p['subject']}, sir.'
            : 'تم التسجيل.',
        payload: p,
        transcription: userReply,
      );
    }
    clearPending();
    return _fallback(useEnglish ? 'Got it.' : 'حسناً.');
  }

  static String _mapAbsenceType(String r) {
    final l = r.toLowerCase();
    if (l.contains('lab') || l.contains('عملي')) return 'lab';
    if (l.contains('section') || l.contains('سكشن')) return 'section';
    return 'lecture';
  }

  // ── AI Prompt ─────────────────────────────────────────────────────────────
  static String _buildPrompt(
    DateTime now,
    List<Subject> subjects,
    List<TaskModel> tasks,
    List<Map<String, dynamic>> absences,
    List<MarkModel> marks,
    List<TimetableEntry> timetable,
    List<StudyTopic> topics,
    List<SubjectNote> notes,
    List<JarvisDocument> documents,
    String userText,
  ) {
    final lang = useEnglish ? 'English' : 'Arabic';
    final fmt = intl.DateFormat('yyyy-MM-dd');
    final dayFmt = intl.DateFormat('EEEE, MMM d');

    final absBuf = StringBuffer();
    for (final s in subjects) {
      final sa = absences.where((a) => a['subjectId'] == s.id).toList();
      final lc = sa.where((a) => a['type'] == 'lecture').length;
      final sc = sa.where((a) => a['type'] == 'section').length;
      final lb = sa.where((a) => a['type'] == 'lab').length;
      absBuf.write(
        '${s.name}: ${lc}L ${sc}S ${lb}Lab '
        '(max ${s.maxLectureAbs}L/${s.maxSectionAbs}S/${s.maxLabAbs}Lab); ',
      );
    }

    final sorted = List<Map<String, dynamic>>.from(absences)
      ..sort(
        (a, b) => ((b['date'] ?? '') as String).compareTo(
          (a['date'] ?? '') as String,
        ),
      );
    final absDetail = sorted
        .take(10)
        .map((a) {
          final sn = subjects
              .firstWhere(
                (s) => s.id == (a['subjectId'] as int?),
                orElse: () => Subject(name: '?'),
              )
              .name;
          return '${a['date']} $sn ${a['type']}';
        })
        .join('; ');

    final upTasks =
        tasks.where((t) => !t.isCompleted && t.dueDate != null).toList()
          ..sort((a, b) => a.dueDate!.compareTo(b.dueDate!));

    final doneTasks = tasks.where((t) => t.isCompleted).toList()
      ..sort(
        (a, b) => (b.completedAt ?? DateTime.now()).compareTo(
          a.completedAt ?? DateTime.now(),
        ),
      );

    final todayClasses =
        timetable.where((e) => e.dayOfWeek == now.weekday).toList()
          ..sort((a, b) => a.startTime.compareTo(b.startTime));

    final marksSummary = marks
        .take(8)
        .map((m) {
          final sn = subjects
              .firstWhere(
                (s) => s.id == m.subjectId,
                orElse: () => Subject(name: '?'),
              )
              .name;
          return '$sn ${m.category}/${m.label}: ${m.obtained}/${m.total}';
        })
        .join('; ');

    final notesSummary = notes.isEmpty
        ? 'None'
        : notes
              .map((n) {
                final sn = subjects
                    .firstWhere(
                      (s) => s.id == n.subjectId,
                      orElse: () => Subject(name: '?'),
                    )
                    .name;
                return '$sn [${n.category}] ${n.title}: ${n.content}';
              })
              .join(' | ');

    final topicsSummary = topics.isEmpty
        ? 'None'
        : topics
              .map((t) {
                final sn = subjects
                    .firstWhere(
                      (s) => s.id == t.subjectId,
                      orElse: () => Subject(name: '?'),
                    )
                    .name;
                return '$sn - ${t.title} (Stage ${t.stage}): ${t.notes}';
              })
              .join(' | ');

    final docsSummary = documents.isEmpty
        ? 'None'
        : documents
              .map((d) {
                final sn = subjects
                    .firstWhere(
                      (s) => s.id == d.subjectId,
                      orElse: () => Subject(name: '?'),
                    )
                    .name;
                return '$sn - Doc ${d.name}: ${d.content}';
              })
              .join(' | ');

    return '''You are $_jarvisName, Iron Man\'s AI assistant for a university student.
Respond ONLY in $lang. Return ONLY valid JSON. No markdown.

TODAY: ${dayFmt.format(now)} | Tomorrow: ${fmt.format(now.add(const Duration(days: 1)))} | +7d: ${fmt.format(now.add(const Duration(days: 7)))}
SUBJECTS: ${subjects.map((s) => s.name).join(', ')}
ABSENCES: $absBuf
RECENT ABS: $absDetail
PENDING TASKS: ${upTasks.isEmpty ? 'None' : upTasks.take(8).map((t) => '${t.title} due ${fmt.format(t.dueDate!)} [${t.type}]').join(', ')}
COMPLETED TASKS / EXAMS: ${doneTasks.isEmpty ? 'None' : doneTasks.take(30).map((t) => '${t.title} [${t.type}]').join(', ')}
TODAY SCHEDULE: ${todayClasses.isEmpty ? 'None' : todayClasses.map((e) {
            final sn = subjects.firstWhere((s) => s.id == e.subjectId, orElse: () => Subject(name: '?')).name;
            return '${e.startTime}-${e.endTime} $sn ${e.type}';
          }).join(', ')}
MARKS: $marksSummary
NOTES: $notesSummary
TOPICS (Study Mastery): $topicsSummary
ANALYZED DOCUMENTS/EXAMS: $docsSummary

PAGES: home(0), tasks(1), exams(2), calendar(3), subjects(4), marks(5), campus(6=timetable/pomodoro)
RULES: 
- ALWAYS acknowledge and congratulate the user if they explicitly or implicitly mention COMPLETED TASKS.
- NEVER use navigate_page for questions like "what is my schedule" or "what are my tasks". 
- ONLY use navigate_page if the user explicitly says "open", "go to", or "show me the page".
- For questions ("what is...", "do I have..."), use brain_chat and answer the question directly using the context.
USER: "$userText"

ACTIONS: navigate_page, navigate_tab, add_task, update_task, delete_task, complete_task,
add_absence, delete_absence, query_absences, add_note, delete_note, query_notes,
add_subject, delete_subject, add_mark, add_reminder,
pomodoro_start, pomodoro_stop, pomodoro_reset, pomodoro_mode,
needs_more_info, brain_chat

EXAMPLES:
{"action":"navigate_page","spoken":"Opening tasks, sir.","payload":{"page":"tasks"}}
{"action":"add_absence","spoken":"Recorded.","payload":{"subject":"Digital Systems","type":"lecture","date":"${fmt.format(now)}"}}
{"action":"query_absences","spoken":"You have 2 lecture absences in Digital Systems with 2 remaining.","payload":{}}
{"action":"add_note","spoken":"Note added.","payload":{"subject":"Digital Systems","title":"Chapter 3","content":"Key points..."}}
{"action":"pomodoro_start","spoken":"Starting focus timer, sir.","payload":{"mode":"focus"}}
{"action":"needs_more_info","spoken":"For which subject, sir?","payload":{"intent":"add_note"}}
{"action":"brain_chat","spoken":"","payload":{}}

Return ONLY JSON. If unsure → brain_chat.''';
  }

  // ── Response parser ───────────────────────────────────────────────────────
  static JarvisAction _parseResponse(
    String content,
    String transcription,
    List<Subject> subjects,
    String? brainContext,
    List<Map<String, String>>? brainHistory,
  ) {
    try {
      var c = content.trim();
      if (c.startsWith('```')) {
        c = c
            .replaceAll(RegExp(r'^```json\s*'), '')
            .replaceAll(RegExp(r'^```\s*'), '')
            .replaceAll(RegExp(r'\s*```$'), '')
            .trim();
      }

      // ── JSON Healer (fixes mid-word server truncations) ──
      if (!c.endsWith('}')) {
        final quoteCount = c.split('"').length - 1;
        if (quoteCount % 2 != 0) {
          c += '"'; // close open string
        }
        c += '}'; // close current object
        // Close parent brackets/braces if nested
        final openBraces = c.split('{').length - 1;
        final closeBraces = c.split('}').length - 1;
        for (var i = 0; i < (openBraces - closeBraces); i++) c += '}';
      }

      final s = c.indexOf('{'), e = c.lastIndexOf('}');
      if (s >= 0 && e > s) c = c.substring(s, e + 1);
      final parsed = jsonDecode(c) as Map<String, dynamic>;
      final action = parsed['action']?.toString().toLowerCase() ?? 'brain_chat';
      final spoken = parsed['spoken']?.toString() ?? '';
      final payload = parsed['payload'] ?? {};

      switch (action) {
        case 'navigate_page':
          return JarvisAction(
            type: JarvisActionType.navigatePage,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'navigate_tab':
          return JarvisAction(
            type: JarvisActionType.navigateTab,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'add_task':
          return JarvisAction(
            type: JarvisActionType.addTask,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'update_task':
          return JarvisAction(
            type: JarvisActionType.updateTask,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'delete_task':
          return JarvisAction(
            type: JarvisActionType.deleteTask,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'complete_task':
          return JarvisAction(
            type: JarvisActionType.completeTask,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'add_absence':
          return JarvisAction(
            type: JarvisActionType.addAbsence,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'delete_absence':
          return JarvisAction(
            type: JarvisActionType.deleteAbsence,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'query_absences':
          return JarvisAction(
            type: JarvisActionType.queryAbsences,
            spokenResponse: spoken,
            payload: {},
            transcription: transcription,
          );
        case 'add_note':
          return JarvisAction(
            type: JarvisActionType.addNote,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'delete_note':
          return JarvisAction(
            type: JarvisActionType.deleteNote,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'query_notes':
          return JarvisAction(
            type: JarvisActionType.queryNotes,
            spokenResponse: spoken,
            payload: {},
            transcription: transcription,
          );
        case 'add_subject':
          return JarvisAction(
            type: JarvisActionType.addSubject,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'delete_subject':
          return JarvisAction(
            type: JarvisActionType.deleteSubject,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'add_mark':
          return JarvisAction(
            type: JarvisActionType.addMark,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'add_reminder':
          return JarvisAction(
            type: JarvisActionType.addReminder,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'pomodoro_start':
          return JarvisAction(
            type: JarvisActionType.pomodoroStart,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'pomodoro_stop':
          return JarvisAction(
            type: JarvisActionType.pomodoroStop,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'pomodoro_reset':
          return JarvisAction(
            type: JarvisActionType.pomodoroReset,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'pomodoro_mode':
          return JarvisAction(
            type: JarvisActionType.pomodoroMode,
            spokenResponse: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'needs_more_info':
          final intent = payload is Map ? payload['intent']?.toString() : null;
          if (intent == 'add_note') {
            _pendingAction = 'add_note_subject';
            _pendingPayload = {'title': 'Voice Note'};
          } else if (intent == 'add_absence') {
            _pendingAction = 'add_absence_subject';
            _pendingPayload = {
              'date': intl.DateFormat('yyyy-MM-dd').format(DateTime.now()),
            };
          } else {
            _pendingAction = intent ?? 'unknown';
            _pendingPayload = {};
          }
          return JarvisAction(
            type: JarvisActionType.needsMoreInfo,
            spokenResponse: spoken,
            followUpQuestion: spoken,
            payload: payload,
            transcription: transcription,
          );
        case 'brain_chat':
        default:
          return JarvisAction(
            type: JarvisActionType.brainChat,
            spokenResponse: spoken,
            payload: {},
            transcription: transcription,
          );
      }
    } catch (e) {
      debugPrint('Parse error: $e');
      return _fallback(
        useEnglish ? 'Could not understand. Rephrase please.' : 'لم أفهم.',
      );
    }
  }

  static void resetConversation() => clearPending();
  static void toggleLanguage() {
    useEnglish = !useEnglish;
    clearPending();
  }

  static JarvisAction _fallback(String m) => JarvisAction(
    type: JarvisActionType.unknown,
    spokenResponse: m,
    payload: {},
    transcription: '',
  );
}
