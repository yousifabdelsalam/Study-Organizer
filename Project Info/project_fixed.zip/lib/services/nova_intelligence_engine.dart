// nova_intelligence_engine.dart
// Phase 2: Subject Intel Cards + Weekly Intelligence Briefing generator.
// Runs on demand and every Friday 9 PM via WorkManager.

import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:flutter/material.dart';
import 'package:workmanager/workmanager.dart';

import '../models/subject.dart';
import '../models/task.dart';
import '../models/timetable.dart';
import '../models/mark.dart';
import '../models/topic.dart';
import 'jarvis_brain_service.dart';
import 'database.dart';

// ── WorkManager task name ─────────────────────────────────────────────────
const _kFridayTask = 'nova_friday_regen';

// ── Background dispatcher removed — now unified in main.dart callbackDispatcher ──

// ─────────────────────────────────────────────────────────────────────────────
class NovaIntelligenceEngine {
  // ── Schedule Friday 9PM regen (called once from main.dart after WM init) ──
  static Future<void> scheduleFridayRegen() async {
    await _scheduleFridayRegen();
  }

  static Future<void> _scheduleFridayRegen() async {
    final now = DateTime.now();
    // Find next Friday 21:00
    int daysUntilFri = (DateTime.friday - now.weekday + 7) % 7;
    if (daysUntilFri == 0 && now.hour >= 21) daysUntilFri = 7;
    final next = DateTime(now.year, now.month, now.day + daysUntilFri, 21, 0);
    final delay = next.difference(now);

    await Workmanager().registerOneOffTask(
      _kFridayTask,
      _kFridayTask,
      initialDelay: delay,
      existingWorkPolicy: ExistingWorkPolicy.replace,
      constraints: Constraints(networkType: NetworkType.connected),
    );
  }

  // ── Friday 9 PM batch run ─────────────────────────────────────────────────
  static Future<void> runFridayRegen() async {
    debugPrint('🧠 NOVA Friday regen starting...');
    try {
      final db = await DatabaseHelper.instance.database;
      final rows = await db.query('subjects');
      final subjects = rows
          .map(
            (r) => Subject(
              id: r['id'] as int?,
              name: r['name'] as String? ?? '',
              doctorName: r['doctorName'] as String? ?? '',
              color: r['color'] as int? ?? 0xFF6C63FF,
              creditHours: r['creditHours'] as int? ?? 3,
              maxLectureAbs: r['maxLectureAbs'] as int? ?? 4,
              maxSectionAbs: r['maxSectionAbs'] as int? ?? 4,
              maxLabAbs: r['maxLabAbs'] as int? ?? 4,
            ),
          )
          .toList();

      // 1. Refresh all intel cards in parallel
      await Future.wait(subjects.map((s) => generateIntelCard(s)));

      // 2. Reschedule self for next Friday
      await _scheduleFridayRegen();

      debugPrint('✅ NOVA Friday regen complete');
    } catch (e) {
      debugPrint('❌ NOVA Friday regen error: $e');
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Subject Intel Card
  // ─────────────────────────────────────────────────────────────────────────
  /// Generates or refreshes the intel card for a subject.
  /// Saves to nova_subject_intel table. Returns the card text.
  static Future<String> generateIntelCard(Subject subject) async {
    if (subject.id == null) return '';
    try {
      final db = await DatabaseHelper.instance.database;

      // Fetch all documents for this subject
      final docRows = await db.query(
        'jarvis_documents',
        where: 'subjectId = ?',
        whereArgs: [subject.id],
      );
      // Create simple doc objects from rows
      final docs = docRows
          .map(
            (r) => _DocInfo(
              type: r['type'] as String? ?? '',
              name: r['name'] as String? ?? '',
              content: r['content'] as String? ?? '',
            ),
          )
          .toList();
      if (docs.isEmpty) return '';

      // Fetch marks for context
      final marks = await db.query(
        'marks',
        where: 'subjectId = ?',
        whereArgs: [subject.id],
      );

      // Fetch topics
      final topics = await db.query(
        'topics',
        where: 'subjectId = ?',
        whereArgs: [subject.id],
      );

      // Fetch subject metadata
      final meta = await db.query(
        'subject_metadata',
        where: 'subjectId = ?',
        whereArgs: [subject.id],
      );
      final instructorFocus = meta.isNotEmpty
          ? (meta.first['instructor_focus'] as String? ?? '')
          : '';

      // Separate past exams from lecture notes
      // pastExams and studyMats not needed directly — just for reference
      // final pastExams = docs.where((d) => d.type == 'past_exam').toList();

      final docSummary = docs
          .map((d) => '[${d.type.toUpperCase()}] ${d.name}')
          .join('\n');
      final docContent = docs
          .map(
            (d) =>
                '=== ${d.name} ===\n${d.content.length > 3000 ? d.content.substring(0, 3000) : d.content}',
          )
          .join('\n\n');

      final marksSummary = marks
          .map(
            (m) =>
                '${m['category']} - ${m['label']}: ${m['obtained']}/${m['total']}',
          )
          .join(', ');

      final topicsSummary = topics
          .map((t) => '${t['title']} (stage ${t['stage']})')
          .join(', ');

      final prompt =
          '''
You are NOVA — an elite academic intel system. Generate a compressed Subject Intel Card.
Output ONLY the card as plain text (no markdown headers, no JSON).
Target: ~800 tokens. Dense, actionable, no fluff.

SUBJECT: ${subject.name}
INSTRUCTOR: ${subject.doctorName.isEmpty ? 'Unknown' : subject.doctorName}
INSTRUCTOR FOCUS: ${instructorFocus.isEmpty ? 'Not specified' : instructorFocus}
DOCUMENTS (${docs.length} files): $docSummary
PAST EXAMS: ${docs.where((d) => d.type == 'past_exam').length}
STUDENT MARKS: ${marksSummary.isEmpty ? 'No marks recorded' : marksSummary}
TOPICS (spaced repetition): ${topicsSummary.isEmpty ? 'None recorded' : topicsSummary}

DOCUMENT CONTENT (truncated):
$docContent

Generate the Subject Intel Card with these exact sections:
EXAM DNA: exam structure, question types, time distribution, difficulty pattern
TOP 5 TOPICS: most frequently tested (with % estimate each)
INSTRUCTOR PATTERNS: what this doctor always tests, what they emphasize, known traps
STUDENT STATUS: current performance trend, weak areas, mastery gaps  
NEVER ASKED: topics in materials that haven't appeared in past exams (overdue to appear)
PREDICTED QUESTIONS: 3-4 specific questions most likely on next exam, with reasoning
''';

      final card = await JarvisBrainService.generateRaw(
        prompt: prompt,
        maxTokens: 900,
        temperature: 0.2,
      );

      if (card != null && card.isNotEmpty) {
        // Save to DB
        await db.insert('nova_subject_intel', {
          'subjectId': subject.id,
          'subjectName': subject.name,
          'cardText': card,
          'documentCount': docs.length,
          'updatedAt': DateTime.now().toIso8601String(),
        }, conflictAlgorithm: ConflictAlgorithm.replace);
        return card;
      }
    } catch (e) {
      debugPrint('Intel card error for ${subject.name}: $e');
    }
    return '';
  }

  /// Load saved intel card from DB.
  static Future<String?> loadIntelCard(int subjectId) async {
    final db = await DatabaseHelper.instance.database;
    final rows = await db.query(
      'nova_subject_intel',
      where: 'subjectId = ?',
      whereArgs: [subjectId],
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first['cardText'] as String?;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Weekly Intelligence Briefing
  // ─────────────────────────────────────────────────────────────────────────
  static Future<String> generateWeeklyBriefing({
    required List<Subject> subjects,
    required List<TaskModel> tasks,
    required List<TimetableEntry> timetable,
    required List<Map<String, dynamic>> absences,
    required List<MarkModel> marks,
    required List<StudyTopic> topics,
  }) async {
    try {
      final db = await DatabaseHelper.instance.database;

      // Load all intel cards
      final cards = StringBuffer();
      for (final s in subjects) {
        if (s.id == null) continue;
        final card = await loadIntelCard(s.id!);
        if (card != null)
          cards.write('\n\n=== ${s.name} INTEL CARD ===\n$card');
      }

      // Absence status per subject
      final absStatus = subjects
          .map((s) {
            if (s.id == null) return '';
            final sa = absences.where((a) => a['subjectId'] == s.id).toList();
            final lc = sa.where((a) => a['type'] == 'lecture').length;
            final sc = sa.where((a) => a['type'] == 'section').length;
            final lbc = sa.where((a) => a['type'] == 'lab').length;
            return '${s.name}: L$lc/${s.maxLectureAbs} S$sc/${s.maxSectionAbs} Lab$lbc/${s.maxLabAbs}';
          })
          .where((s) => s.isNotEmpty)
          .join(' | ');

      // Upcoming exams
      final now = DateTime.now();
      final examStr = tasks
          .where(
            (t) =>
                !t.isCompleted &&
                t.isExam &&
                t.dueDate != null &&
                t.dueDate!.isAfter(now),
          )
          .map((t) {
            final days = t.dueDate!.difference(now).inDays;
            final sub =
                subjects
                    .where((s) => s.id == t.subjectId)
                    .map((s) => s.name)
                    .firstOrNull ??
                '?';
            return '${t.title} ($sub) in $days days';
          })
          .join(' | ');

      final prompt =
          '''
You are NOVA — elite academic intelligence AI. Generate a Weekly Intelligence Briefing.
Format: plain text with these exact section headers (use ALL CAPS header + colon):

THREAT ASSESSMENT: Rate each subject 🔴CRITICAL/🟠URGENT/🟡WATCH/🟢ON TRACK with exam countdown and absence status. Be blunt.

A+ PROBABILITY: Per subject, honest % chance of A+ this semester with 1-line reasoning.

THIS WEEK'S MANDATORY ACTIONS: Top 5 priority actions in order. Specific, actionable, no vague advice.

THE ONE THING: Single most important action this week. Make it count.

INTEL CARDS:${cards.isEmpty ? ' (No documents uploaded yet)' : cards.toString()}

ABSENCE STATUS: $absStatus
UPCOMING EXAMS: ${examStr.isEmpty ? 'None scheduled' : examStr}
TODAY: ${now.day}/${now.month}/${now.year} (${['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][now.weekday - 1]})

Write like a tactical military briefing officer who also happens to care deeply about this student's success.
Be direct. Flag real dangers. End with one motivational line.
''';

      final briefing = await JarvisBrainService.generateRaw(
        prompt: prompt,
        maxTokens: 1200,
        temperature: 0.3,
      );

      if (briefing != null && briefing.isNotEmpty) {
        await db.insert('nova_weekly_briefing', {
          'briefingText': briefing,
          'createdAt': DateTime.now().toIso8601String(),
          'weekNumber': _weekNum(now),
        }, conflictAlgorithm: ConflictAlgorithm.replace);
        return briefing;
      }
    } catch (e) {
      debugPrint('Weekly briefing error: $e');
    }
    return '';
  }

  static Future<String?> loadLatestBriefing() async {
    final db = await DatabaseHelper.instance.database;
    final rows = await db.query(
      'nova_weekly_briefing',
      orderBy: 'createdAt DESC',
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first['briefingText'] as String?;
  }

  static int _weekNum(DateTime d) {
    final doy = d.difference(DateTime(d.year)).inDays + 1;
    return ((doy - d.weekday + 10) / 7).floor();
  }
}

// ── Simple doc info holder for intel engine ──────────────────────────────
class _DocInfo {
  final String type, name, content;
  const _DocInfo({
    required this.type,
    required this.name,
    required this.content,
  });
}
