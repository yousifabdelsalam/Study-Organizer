// daily_schedule_page.dart — Weekly schedule builder (30-min slots, 6am-midnight)
// User sets their fixed weekly template. NOVA reads free slots to plan study blocks.

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ── Slot labels + colors ──────────────────────────────────────────────────
const kSlotLabels = ['Sleep', 'Class', 'Gym', 'Commute', 'Family', 'Mosque', 'Free', 'Work', 'Other'];
const kSlotColors = {
  'Sleep':    Color(0xFF1A1A3E),
  'Class':    Color(0xFF6C63FF),
  'Gym':      Color(0xFF2ED573),
  'Commute':  Color(0xFFFF9F43),
  'Family':   Color(0xFFFF6B81),
  'Mosque':   Color(0xFF17C0EB),
  'Free':     Color(0xFF2D2D4E),   // NOVA fills these
  'Work':     Color(0xFFFFDD59),
  'Other':    Color(0xFF808080),
  '':         Color(0xFF1A1A2E),   // empty
};

const _prefKey = 'nova_weekly_schedule';

class DailySchedulePage extends StatefulWidget {
  const DailySchedulePage({super.key});
  @override State<DailySchedulePage> createState() => _DailySchedulePageState();
}

class _DailySchedulePageState extends State<DailySchedulePage>
    with SingleTickerProviderStateMixin {

  late TabController _tabs;
  // schedule[day][slotIndex] = label string
  final List<List<String>> _schedule = List.generate(7, (_) => List.generate(36, (_) => ''));
  bool _loading = true;

  static const _days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  // Slots: 6:00 → 23:30 = 36 half-hour slots
  static String _slotLabel(int i) {
    final totalMins = 360 + i * 30; // start 6:00 = 360 min
    final h = totalMins ~/ 60;
    final m = totalMins % 60;
    final h12 = h > 12 ? h - 12 : (h == 0 ? 12 : h);
    final suf = h >= 12 ? 'PM' : 'AM';
    return m == 0 ? '$h12 $suf' : '$h12:${m.toString().padLeft(2,'0')} $suf';
  }

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 7, vsync: this, initialIndex: DateTime.now().weekday - 1);
    _load();
  }

  @override void dispose() { _tabs.dispose(); super.dispose(); }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw   = prefs.getString(_prefKey);
    if (raw != null) {
      try {
        final decoded = jsonDecode(raw) as List;
        for (int d = 0; d < 7 && d < decoded.length; d++) {
          final day = decoded[d] as List;
          for (int s = 0; s < 36 && s < day.length; s++) {
            _schedule[d][s] = day[s] as String? ?? '';
          }
        }
      } catch (_) {}
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefKey, jsonEncode(_schedule));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('✅ Schedule saved. NOVA will use this for study planning.'),
        backgroundColor: Color(0xFF1A3A1A),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A1A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF12122A),
        title: const Row(children: [
          Icon(Icons.calendar_view_week_rounded, color: Color(0xFF39FF14), size: 20),
          SizedBox(width: 8),
          Text('Weekly Schedule', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        ]),
        iconTheme: const IconThemeData(color: Colors.white70),
        actions: [
          TextButton(
            onPressed: _save,
            child: const Text('SAVE', style: TextStyle(color: Color(0xFF39FF14), fontWeight: FontWeight.w900, letterSpacing: 1.5)),
          ),
        ],
        bottom: TabBar(
          controller: _tabs,
          tabs: _days.map((d) => Tab(text: d)).toList(),
          labelColor: const Color(0xFF39FF14),
          unselectedLabelColor: Colors.white38,
          indicatorColor: const Color(0xFF39FF14),
          indicatorSize: TabBarIndicatorSize.label,
          labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFF39FF14)))
          : TabBarView(
              controller: _tabs,
              children: List.generate(7, (day) => _dayGrid(day)),
            ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFF39FF14).withOpacity(0.15),
        foregroundColor: const Color(0xFF39FF14),
        icon: const Icon(Icons.info_outline_rounded),
        label: const Text('Free = NOVA plans here', style: TextStyle(fontSize: 12)),
        onPressed: () {},
        elevation: 0,
      ),
    );
  }

  Widget _dayGrid(int day) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 80),
      itemCount: 36,
      itemBuilder: (_, slot) => _slotTile(day, slot),
    );
  }

  Widget _slotTile(int day, int slot) {
    final label = _schedule[day][slot];
    final color = kSlotColors[label] ?? const Color(0xFF1A1A2E);
    final isFree = label == 'Free' || label.isEmpty;

    return GestureDetector(
      onTap: () => _pickLabel(day, slot),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 44,
        margin: const EdgeInsets.symmetric(vertical: 1.5),
        decoration: BoxDecoration(
          color: color.withOpacity(label.isEmpty ? 0.3 : 0.85),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isFree
                ? const Color(0xFF39FF14).withOpacity(0.15)
                : color.withOpacity(0.5),
          ),
        ),
        child: Row(children: [
          SizedBox(
            width: 60,
            child: Center(
              child: Text(
                _slotLabel(slot),
                style: const TextStyle(color: Colors.white38, fontSize: 10),
              ),
            ),
          ),
          Container(width: 1, color: Colors.white12),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label.isEmpty ? 'Tap to assign' : label,
              style: TextStyle(
                color: label.isEmpty ? Colors.white24 : Colors.white,
                fontSize: 13,
                fontWeight: label.isEmpty ? FontWeight.normal : FontWeight.w600,
              ),
            ),
          ),
          if (label.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onTap: () => setState(() => _schedule[day][slot] = ''),
                child: const Icon(Icons.clear_rounded, color: Colors.white24, size: 16),
              ),
            ),
        ]),
      ),
    );
  }

  Future<void> _pickLabel(int day, int slot) async {
    final chosen = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: const Color(0xFF12122A),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('${_days[day]}  ${_slotLabel(slot)}',
                style: const TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8, runSpacing: 8,
              children: [...kSlotLabels, ''].map((lbl) {
                final c = kSlotColors[lbl] ?? const Color(0xFF1A1A2E);
                return GestureDetector(
                  onTap: () => Navigator.pop(context, lbl),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: c.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.white12),
                    ),
                    child: Text(
                      lbl.isEmpty ? '✕ Clear' : lbl,
                      style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 8),
          ]),
        ),
      ),
    );
    if (chosen != null && mounted) setState(() => _schedule[day][slot] = chosen);
  }
}
