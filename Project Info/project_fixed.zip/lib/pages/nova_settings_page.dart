// nova_settings_page.dart — All NOVA settings in one place
// Home location, daily check-ins, distraction watchdog.

import 'package:flutter/material.dart';
import '../services/nova_location_service.dart';
import '../services/nova_watchdog_service.dart';
import '../services/notifications.dart';
import '../widgets/glass.dart';

class NovaSettingsPage extends StatefulWidget {
  const NovaSettingsPage({super.key});
  @override
  State<NovaSettingsPage> createState() => _NovaSettingsPageState();
}

class _NovaSettingsPageState extends State<NovaSettingsPage> {
  // ── Location ──
  bool _homeSet = false;
  bool _savingHome = false;

  // ── Check-in slots (up to 3) ──
  final List<TimeOfDay?> _checkins = [
    const TimeOfDay(hour: 7, minute: 0), // morning
    const TimeOfDay(hour: 14, minute: 0), // afternoon
    null, // evening (off)
  ];
  final List<bool> _checkinEnabled = [true, true, false];

  // ── Watchdog ──
  List<Map<String, dynamic>> _watchedApps = [];
  bool _watchdogEnabled = false;

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    await NovaLocationService.checkHomeSet();
    final apps = await NovaWatchdogService.getWatchedApps();
    if (mounted) {
      setState(() {
        _homeSet = NovaLocationService.hasHomeSet;
        _watchedApps = apps;
        _watchdogEnabled = apps.isNotEmpty;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A1A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF12122A),
        title: const Row(
          children: [
            Icon(Icons.psychology_rounded, color: Color(0xFF39FF14), size: 22),
            SizedBox(width: 8),
            Text(
              'NOVA Settings',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        iconTheme: const IconThemeData(color: Colors.white70),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _sectionHeader('📍 Home Location'),
          _locationCard(),
          const SizedBox(height: 16),
          _sectionHeader('🕐 Daily Check-ins'),
          _checkinsCard(),
          const SizedBox(height: 16),
          _sectionHeader('🛡️ Distraction Guard'),
          _watchdogCard(),
        ],
      ),
    );
  }

  // ── Location Card ─────────────────────────────────────────────────────────
  Widget _locationCard() {
    return _Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _homeSet ? '✅ Home location saved' : '📍 No home location set',
            style: TextStyle(
              color: _homeSet ? const Color(0xFF39FF14) : Colors.white70,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'When you\'re at home, NOVA speaks briefs aloud. When away, it shows a silent card.',
            style: TextStyle(color: Colors.white38, fontSize: 12),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF39FF14).withOpacity(0.15),
                    foregroundColor: const Color(0xFF39FF14),
                    side: const BorderSide(color: Color(0xFF39FF14)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  icon: _savingHome
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Color(0xFF39FF14),
                          ),
                        )
                      : const Icon(Icons.my_location_rounded, size: 18),
                  label: Text(
                    _savingHome
                        ? 'Saving...'
                        : _homeSet
                        ? 'Update Home'
                        : 'Set Home Here',
                  ),
                  onPressed: _savingHome ? null : _saveHome,
                ),
              ),
              if (_homeSet) ...[
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(
                    Icons.delete_outline,
                    color: Colors.redAccent,
                  ),
                  onPressed: () async {
                    await NovaLocationService.clearHome();
                    if (mounted) setState(() => _homeSet = false);
                  },
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _saveHome() async {
    setState(() => _savingHome = true);
    final ok = await NovaLocationService.saveHomeLocation();
    if (mounted) {
      setState(() {
        _savingHome = false;
        _homeSet = ok;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            ok
                ? '✅ Home location saved!'
                : '❌ Could not get location. Check permissions.',
          ),
          backgroundColor: ok
              ? const Color(0xFF1A3A1A)
              : const Color(0xFF3A1A1A),
        ),
      );
    }
  }

  // ── Check-ins Card ────────────────────────────────────────────────────────
  Widget _checkinsCard() {
    const labels = ['Morning', 'Afternoon', 'Evening'];
    return _Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'NOVA will send a briefing notification at each enabled time.',
            style: TextStyle(color: Colors.white38, fontSize: 12),
          ),
          const SizedBox(height: 12),
          ...List.generate(3, (i) => _checkinRow(i, labels[i])),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF6C63FF).withOpacity(0.2),
                foregroundColor: const Color(0xFF9D97FF),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onPressed: _saveCheckIns,
              child: const Text('Save Check-in Schedule'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _checkinRow(int i, String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Switch(
            value: _checkinEnabled[i],
            onChanged: (v) => setState(() => _checkinEnabled[i] = v),
            activeColor: const Color(0xFF39FF14),
          ),
          const SizedBox(width: 8),
          Text(
            label,
            style: const TextStyle(color: Colors.white70, fontSize: 14),
          ),
          const Spacer(),
          if (_checkinEnabled[i])
            GestureDetector(
              onTap: () => _pickTime(i),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E2139),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.white12),
                ),
                child: Text(
                  _checkins[i]?.format(context) ?? '--:--',
                  style: const TextStyle(
                    color: Color(0xFF9D97FF),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _pickTime(int i) async {
    final t = await showTimePicker(
      context: context,
      initialTime: _checkins[i] ?? const TimeOfDay(hour: 8, minute: 0),
    );
    if (t != null && mounted) setState(() => _checkins[i] = t);
  }

  Future<void> _saveCheckIns() async {
    final enabled = <TimeOfDay>[];
    for (int i = 0; i < 3; i++) {
      if (_checkinEnabled[i] && _checkins[i] != null)
        enabled.add(_checkins[i]!);
    }
    await NotifService.scheduleNovaCheckIns(enabled);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Check-in schedule saved'),
          backgroundColor: Color(0xFF1A3A1A),
        ),
      );
    }
  }

  // ── Watchdog Card ─────────────────────────────────────────────────────────
  Widget _watchdogCard() {
    return _Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Track daily time on distracting apps and get alerted when you\'ve gone over.',
                  style: TextStyle(color: Colors.white38, fontSize: 12),
                ),
              ),
              Switch(
                value: _watchdogEnabled,
                onChanged: (v) async {
                  setState(() => _watchdogEnabled = v);
                  if (v) {
                    await NovaWatchdogService.startWatchdog();
                  } else {
                    await NovaWatchdogService.stopWatchdog();
                  }
                },
                activeColor: const Color(0xFF39FF14),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.orange.withOpacity(0.08),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.orange.withOpacity(0.3)),
            ),
            child: const Row(
              children: [
                Icon(Icons.info_outline, color: Colors.orange, size: 14),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Requires "Usage Access" permission: Settings → Apps → Special App Access → Usage Access → Study Organizer → Allow',
                    style: TextStyle(color: Colors.orange, fontSize: 11),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          ..._watchedApps.map((app) => _appRow(app)),
          const SizedBox(height: 8),
          TextButton.icon(
            icon: const Icon(
              Icons.add_circle_outline,
              color: Color(0xFF6C63FF),
            ),
            label: const Text(
              'Add App',
              style: TextStyle(color: Color(0xFF6C63FF)),
            ),
            onPressed: _showAddAppSheet,
          ),
        ],
      ),
    );
  }

  Widget _appRow(Map<String, dynamic> app) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          const Icon(Icons.smartphone_rounded, color: Colors.white38, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  app['name'] as String,
                  style: const TextStyle(color: Colors.white, fontSize: 13),
                ),
                Text(
                  app['package'] as String,
                  style: const TextStyle(color: Colors.white38, fontSize: 10),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              color: Colors.orange.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.orange.withOpacity(0.3)),
            ),
            child: Text(
              '${app['limitMinutes']} min',
              style: const TextStyle(color: Colors.orange, fontSize: 11),
            ),
          ),
          const SizedBox(width: 4),
          IconButton(
            icon: const Icon(
              Icons.remove_circle_outline,
              color: Colors.redAccent,
              size: 20,
            ),
            onPressed: () async {
              await NovaWatchdogService.removeApp(app['package'] as String);
              final apps = await NovaWatchdogService.getWatchedApps();
              if (mounted) setState(() => _watchedApps = apps);
            },
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(),
          ),
        ],
      ),
    );
  }

  Future<void> _showAddAppSheet() async {
    final pkgCtrl = TextEditingController();
    final nameCtrl = TextEditingController();
    final limitCtrl = TextEditingController(text: '30');
    String? selectedPreset;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF12122A),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
          left: 20,
          right: 20,
          top: 20,
        ),
        child: StatefulBuilder(
          builder: (_, ss) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Add App to Watch',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Quick add:',
                style: TextStyle(color: Colors.white54, fontSize: 12),
              ),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: kCommonDistractors.map((d) {
                  final sel = selectedPreset == d['package'];
                  return GestureDetector(
                    onTap: () {
                      ss(() => selectedPreset = d['package']);
                      pkgCtrl.text = d['package']!;
                      nameCtrl.text = d['name']!;
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: sel
                            ? const Color(0xFF6C63FF).withOpacity(0.3)
                            : const Color(0xFF1E2139),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: sel ? const Color(0xFF6C63FF) : Colors.white12,
                        ),
                      ),
                      child: Text(
                        d['name']!,
                        style: TextStyle(
                          color: sel ? const Color(0xFF9D97FF) : Colors.white70,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: nameCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'App name',
                  labelStyle: TextStyle(color: Colors.white38),
                ),
              ),
              TextField(
                controller: pkgCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  labelText: 'Package (e.g. com.instagram.android)',
                  labelStyle: TextStyle(color: Colors.white38),
                ),
              ),
              TextField(
                controller: limitCtrl,
                style: const TextStyle(color: Colors.white),
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Daily limit (minutes)',
                  labelStyle: TextStyle(color: Colors.white38),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6C63FF),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  onPressed: () async {
                    final pkg = pkgCtrl.text.trim();
                    final name = nameCtrl.text.trim();
                    final limit = int.tryParse(limitCtrl.text) ?? 30;
                    if (pkg.isEmpty || name.isEmpty) return;
                    await NovaWatchdogService.addApp(pkg, name, limit);
                    final apps = await NovaWatchdogService.getWatchedApps();
                    if (mounted) setState(() => _watchedApps = apps);
                    if (ctx.mounted) Navigator.pop(ctx);
                  },
                  child: const Text(
                    'Add App',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionHeader(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 8, left: 2),
    child: Text(
      t,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 15,
        fontWeight: FontWeight.w700,
      ),
    ),
  );
}

class _Card extends StatelessWidget {
  final Widget child;
  const _Card({required this.child});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: const Color(0xFF12122A),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: Colors.white.withOpacity(0.07)),
    ),
    child: child,
  );
}
